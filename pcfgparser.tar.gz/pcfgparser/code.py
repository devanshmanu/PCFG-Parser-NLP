from nltk.corpus import brown
from gensim import models
from cfg import *
from scipy.spatial.distance import *

corpus = list(brown.sents())
model = models.Word2Vec(corpus,size = 20,window = 5,min_count=1,workers = 4)
f = open("data/weighted.rule")
tags = ['<UNK>']
cfg_words = []
for line in f:
	line = line.split()
	if line[0] not in tags:
		tags.append(line[0])

	if line[2] not in tags:
		tags.append(line[2])

f = open("data/weighted.rule")
for line in f:
	line = line.split()
	if line[1] not in tags:
		cfg_words.append(line[1])


parser = PCFGParser()
sent = "fat Devansh"

for word in sent.split():
	if word not in model:
		corpus.append(sent.split())
		model = models.Word2Vec(corpus,size = 20,window = 5,min_count=1,workers = 4)
		break


replaced_sent = []
replaced_word = dict()

for word in sent.split():
	if word in cfg_words:
		replaced_sent.append(word)
	else:
		a = model[word]
		tmp = 1000000
		tmp_w = ""
		for cfg_word in cfg_words:
			tmp_eu = euclidean(a, model[cfg_word])
			if tmp_eu < tmp:
				tmp_w = cfg_word
				tmp = tmp_eu
		replaced_sent.append(tmp_w)
		replaced_word[tmp_w] = word
#print replaced_sent
tree = parser.parse(replaced_sent)
tree = str(tree)
for word in replaced_word.keys():
	tree=tree.replace(word, replaced_word[word])

print tree