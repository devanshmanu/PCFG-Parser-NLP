from cfg import *
parser = PCFGParser()
sent = "My name is very popular"
tree = parser.parse(sent.split())
print tree